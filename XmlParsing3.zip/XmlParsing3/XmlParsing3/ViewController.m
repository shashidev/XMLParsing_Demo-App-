//
//  ViewController.m
//  XmlParsing3
//
//  Created by Kumar on 18/11/15.
//  Copyright (c) 2015 Kumar. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.nameArray=[[NSMutableArray alloc]init];
    self.authorArray=[[NSMutableArray alloc]init];
    self.myTableView.delegate=self;
    self.myTableView.dataSource=self;
    NSURL *path=[[NSBundle mainBundle]URLForResource:@"Books" withExtension:@"xml"];
    self.xmlParse=[[NSXMLParser alloc]initWithContentsOfURL:path];
    self.xmlParse.delegate=self;
    [self.xmlParse parse];
    
    
}

-(void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
    if([elementName isEqualToString:@"Name"])
    {
        self.theResponse=[[NSMutableString alloc]init];
    }
    else if ([elementName isEqualToString:@"Author"])
    {
        self.theResponse=[[NSMutableString alloc]init];
    }
}
-(void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    [self.theResponse appendString:string];
}
-(void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    if([elementName isEqualToString:@"Name"])
    {
        [self.nameArray addObject:self.theResponse];
        //self.theResponse=nil;
    }
    else if ([elementName isEqualToString:@"Author"])
    {
        [self.authorArray addObject:self.theResponse];
        self.theResponse=nil;
    }
    //NSLog(@"%@",self.nameArray);
    //NSLog(@"%@",self.authorArray);
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [self.authorArray count];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.nameArray count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if(!cell)
    {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    
         cell.textLabel.text=[_nameArray objectAtIndex:indexPath.row];
   
    return cell;
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    
    return [_authorArray objectAtIndex:section];
}

@end
